# format.rb: Written by Tadayoshi Funaba 1999-2011
